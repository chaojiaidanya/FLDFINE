from engine.extre_module.torch_utils import check_cuda

if __name__ == "__main__":
    check_cuda()